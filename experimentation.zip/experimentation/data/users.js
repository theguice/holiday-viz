
function User()
{
    this.id = 0;
    this.name = "";
    this.avatar = "";
    this.twitter = "";
    this.instagram = "";
    this.color = "#fff";
    this.steps =[];
}

var users = [
    {
        "id": 0,
        "name": "Shaun",
        "avatar": "images/shaun.png",
        "twitter": "@theguice",
        "instagram": "theguice",
        "color": "#0ff",
        "steps": []
    },
    {
        "id": 1,
        "name": "Divyakumar",
        "avatar": "images/divya.png",
        "twitter": "",
        "instagram": "",
        "color": "#ff0",
        "steps": []
    },
    {
        "id": 2,
        "name": "Hassan",
        "avatar": "images/hassan.png",
        "twitter": "",
        "instagram": "",
        "color": "#f0f",
        "steps": []
    }
];